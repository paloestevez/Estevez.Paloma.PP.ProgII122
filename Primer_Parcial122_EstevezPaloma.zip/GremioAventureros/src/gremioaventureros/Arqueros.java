package gremioaventureros;

public class Arqueros extends Aventureros implements Entrenable {

    private final int precision;

    public Arqueros(String id, String nombre, Rango rango, int precision) {
        super(id, nombre, rango);
        validarPrecision(precision);
        this.precision = precision;
    }

    private void validarPrecision(int precision) {
        if (precision <= 0) {
            throw new IllegalArgumentException("La precision no puede ser menor a 0");
        }
    }

    @Override
    public void atacar() {
        System.out.println("Soy un arquero atacando");
    }

    @Override
    public int calcularPoder() {
        return precision * 3;
    }

    @Override
    public void entrenar() {
        System.out.println("Arquero participando de un entrenamiento especial");
    }

    
}
