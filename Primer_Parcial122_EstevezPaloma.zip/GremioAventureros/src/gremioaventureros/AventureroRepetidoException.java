package gremioaventureros;


public class AventureroRepetidoException extends Exception {
    public final static String MENSAJE = "Aventurero repetido";
    
    public AventureroRepetidoException(){
    super(MENSAJE);
    }
    
    public AventureroRepetidoException(String mensaje){
    super(mensaje);
    }
    
    
}
