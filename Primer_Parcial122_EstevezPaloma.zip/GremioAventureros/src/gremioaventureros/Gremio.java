package gremioaventureros;

import java.util.ArrayList;

public class Gremio {

    private String nombre;
    private ArrayList<Aventureros> aventureros;

    public Gremio(String nombre) {
        validarNombre(nombre);
        this.nombre = nombre;
        this.aventureros = new ArrayList<>();
    }

    private void validarNombre(String nombre) {
        if (nombre == null || nombre.isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede estar vacio");
        }
    }

    public void agregarAventurero(Aventureros aventurero) throws AventureroRepetidoException {
        if (aventureros.contains(aventurero)) {
            throw new AventureroRepetidoException();
        }

        aventureros.add(aventurero);
    }

    public ArrayList<Aventureros> obtenerAventureros() {
        return new ArrayList<>(aventureros);
    }

    public ArrayList<Aventureros> filtrarPorRango(Rango rango) {
        ArrayList<Aventureros> resultado = new ArrayList<>();

        for (Aventureros a : aventureros) {
            if (a.getRango() == rango) {
                resultado.add(a);
            }
        }
        return resultado;
    }

    public ArrayList<Aventureros> obtenerAventurerosPoderosos(int poderMinimo) {
        ArrayList<Aventureros> resultado = new ArrayList<>();

        for (Aventureros a : aventureros) {
            if (a.calcularPoder() >= poderMinimo) {
                resultado.add(a);
            }
        }

        return resultado;
    }

}
