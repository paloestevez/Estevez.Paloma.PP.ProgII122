package gremioaventureros;


public enum Rango {
    BRONCE,
    PLATA,
    ORO
    
}
