package gremioaventureros;

import java.util.Objects;

public abstract class Aventureros {

    private final String id;
    private final String nombre;
    private final Rango rango;

    public Aventureros(String id, String nombre, Rango rango) {
        validarParametros(id, nombre, rango);
        this.id = id;
        this.nombre = nombre;
        this.rango = rango;
    }

    protected abstract void atacar();

    protected abstract int calcularPoder();

    private void validarId(String id) {
        if (id == null || id.isEmpty()) {
            throw new IllegalArgumentException("El codigo de identificacion no puede estar vacio");
        }
    }

    private void validarNombre(String nombre) {
        if (nombre == null || nombre.isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede estar vacio");
        }
    }

    private void validarRango(Rango rango) {
        if (rango == null) {
            throw new IllegalArgumentException("El rango no puede estar vacio");
        }
    }

    private void validarParametros(String id, String nombre, Rango rango) {
        validarId(id);
        validarNombre(nombre);
        validarRango(rango);
    }

    public Rango getRango() {
        return rango;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null) {
            return false;
        }

        if (this == o) {
            return true;
        }

        if (o instanceof Aventureros otro) {
            return id.equals(otro.id) && nombre.equals(otro.nombre);
        }

        return false;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, nombre);
    }

    @Override
    public String toString() {
        return "Codigo de identificacion: " + id + ", Nombre: " + nombre + ", Rango: " + rango;
    }

    
    
}
