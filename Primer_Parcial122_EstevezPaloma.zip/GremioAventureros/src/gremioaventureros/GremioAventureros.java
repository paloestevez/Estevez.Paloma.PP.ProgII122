package gremioaventureros;

import java.util.List;

public class GremioAventureros {

    public static void main(String[] args) {

        Gremio gremio = new Gremio("Guardianes de Eldoria");
        try {
            gremio.agregarAventurero(new Guerreros("G-01", "Arin", Rango.ORO, 30));

            gremio.agregarAventurero(new Magos("M-02", "Lyra", Rango.PLATA, 45));

            gremio.agregarAventurero(new Arqueros("A-03", "Nox", Rango.BRONCE, 18));

            gremio.agregarAventurero(new Guerreros("G-04", "Borin", Rango.PLATA, 20));

            gremio.agregarAventurero(new Magos("G-01", "Arin", Rango.BRONCE, 99));
        } catch (AventureroRepetidoException e) {
            System.out.println("Error " + e.getMessage());
        }

        System.out.println("Aventureros registrados:");

        mostrarAventureros(gremio.obtenerAventureros());

        System.out.println("\nAtaques:");

        mostrarAtaques(gremio.obtenerAventureros());

        System.out.println("\nEntrenamientos:");

        mostrarEntrenamientos(gremio.obtenerAventureros());

        System.out.println("\nPoder de combate:");

        mostrarPoderes(gremio.obtenerAventureros());

        System.out.println("\nAventureros de rango PLATA:");

        mostrarAventureros(gremio.filtrarPorRango(Rango.PLATA));

        System.out.println("\nAventureros con poder >= 55:");

        mostrarAventureros(gremio.obtenerAventurerosPoderosos(55));

    }

    private static void mostrarAventureros(List<Aventureros> aventureros) {
        for (Aventureros a : aventureros) {
            System.out.println(a);
        }
    }

    private static void mostrarAtaques(List<Aventureros> aventureros) {
        for (Aventureros a : aventureros) {
            a.atacar();
        }
    }

    private static void mostrarEntrenamientos(List<Aventureros> aventureros) {
        for (Aventureros a : aventureros) {
            if (a instanceof Entrenable entrenable) {
                entrenable.entrenar();
            }

        }

    }

    private static void mostrarPoderes(List<Aventureros> aventureros) {
        for (Aventureros a : aventureros) {
            System.out.println(a.calcularPoder());
        }

    }

}
