package gremioaventureros;


public interface Entrenable {
    
    void entrenar();
    
}
