package gremioaventureros;

public class Guerreros extends Aventureros implements Entrenable {

    private final int fuerza;

    public Guerreros(String id, String nombre, Rango rango, int fuerza) {
        super(id, nombre, rango);
        validarFuerza(fuerza);
        this.fuerza = fuerza;
    }

    private void validarFuerza(int fuerza) {
        if (fuerza <= 0) {
            throw new IllegalArgumentException("La fuerza no puede ser menor a 0");
        }
    }

    @Override
    public void atacar() {
        System.out.println("Soy un guerrero atacando");
    }

    @Override
    public int calcularPoder() {
        return fuerza * 2;
    }

    @Override
    public void entrenar() {
        System.out.println("Guerrero participando de un entrenamiento especial");
    }

    
    
}
