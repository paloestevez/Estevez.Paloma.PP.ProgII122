package gremioaventureros;

public class Magos extends Aventureros {

    private final int mana;

    public Magos(String id, String nombre, Rango rango, int mana) {
        super(id, nombre, rango);
        validarMana(mana);
        this.mana = mana;
    }

    private void validarMana(int mana) {
        if (mana <= 0) {
            throw new IllegalArgumentException("El mana no puede ser menor a 0");
        }
    }

    @Override
    public void atacar() {
        System.out.println("Soy un mago atacando");
    }

    @Override
    public int calcularPoder() {
        return mana + 10;
    }

    
}
